package net.minecraft.item;

public enum EnumAction
{
    NONE,
    EAT,
    DRINK,
    BLOCK,
    BOW;
}
